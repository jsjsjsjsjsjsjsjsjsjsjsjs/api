# Pyarmor 8.2.5 (trial), 000000, 2023-06-12T12:51:47.770379
from .pyarmor_runtime import __pyarmor__
